module.exports =  [
    {
        id: 1,
        nomi:"Shartnoma rasmiylashtirish"
    }
]